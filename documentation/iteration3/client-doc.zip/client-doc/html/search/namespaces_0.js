var searchData=
[
  ['client_0',['client',['../namespacefit_1_1biesp_1_1oneplan_1_1client.html',1,'fit::biesp::oneplan']]],
  ['exception_1',['exception',['../namespacefit_1_1biesp_1_1oneplan_1_1client_1_1exception.html',1,'fit::biesp::oneplan::client']]],
  ['models_2',['models',['../namespacefit_1_1biesp_1_1oneplan_1_1client_1_1models.html',1,'fit::biesp::oneplan::client']]]
];
