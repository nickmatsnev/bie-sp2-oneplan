var searchData=
[
  ['clientapplication_0',['ClientApplication',['../classfit_1_1biesp_1_1oneplan_1_1client_1_1_client_application.html',1,'fit::biesp::oneplan::client']]],
  ['clientapplication_2ejava_1',['ClientApplication.java',['../_client_application_8java.html',1,'']]],
  ['create_2',['create',['../classfit_1_1biesp_1_1oneplan_1_1client_1_1_user_client.html#a942dd85af5380a4e58783d4ed9c37919',1,'fit::biesp::oneplan::client::UserClient']]],
  ['createevent_3',['createEvent',['../classfit_1_1biesp_1_1oneplan_1_1client_1_1_user_client.html#afec01c5c7bf599d07f2cca3633a4c782',1,'fit::biesp::oneplan::client::UserClient']]],
  ['createlocation_4',['createLocation',['../classfit_1_1biesp_1_1oneplan_1_1client_1_1_user_client.html#a9c797d57dc33b45ed746e4ba8638fd15',1,'fit::biesp::oneplan::client::UserClient']]]
];
