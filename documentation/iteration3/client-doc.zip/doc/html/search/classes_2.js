var searchData=
[
  ['friendmodel_0',['FriendModel',['../classfit_1_1biesp_1_1oneplan_1_1client_1_1models_1_1_friend_model.html',1,'fit::biesp::oneplan::client::models']]]
];
