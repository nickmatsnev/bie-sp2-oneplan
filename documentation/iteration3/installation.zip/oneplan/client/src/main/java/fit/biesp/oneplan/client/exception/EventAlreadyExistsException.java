package fit.biesp.oneplan.client.exception;

public class EventAlreadyExistsException extends Exception {
    public EventAlreadyExistsException (String message) {
        super(message);
    }
}
