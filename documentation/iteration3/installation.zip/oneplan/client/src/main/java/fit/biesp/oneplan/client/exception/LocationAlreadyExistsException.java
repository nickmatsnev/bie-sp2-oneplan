package fit.biesp.oneplan.client.exception;

public class LocationAlreadyExistsException extends Exception {
    public LocationAlreadyExistsException (String message) {
        super(message);
    }
}
