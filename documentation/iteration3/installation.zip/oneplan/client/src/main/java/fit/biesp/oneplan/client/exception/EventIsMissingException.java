package fit.biesp.oneplan.client.exception;

public class EventIsMissingException extends Exception {
    public EventIsMissingException (String message) {
        super(message);
    }
}
