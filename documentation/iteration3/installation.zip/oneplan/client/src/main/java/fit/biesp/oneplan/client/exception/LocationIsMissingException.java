package fit.biesp.oneplan.client.exception;

public class LocationIsMissingException extends Exception {
    public LocationIsMissingException(String message) {
        super(message);
    }
}
