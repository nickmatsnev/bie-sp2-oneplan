package fit.biesp.oneplan;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OneplanApplication {

	public static void main(String[] args) {
		SpringApplication.run(OneplanApplication.class, args);
	}

}
