package fit.biesp.oneplan.exception;

public class LocationAlreadyExistsException extends Exception {
    public LocationAlreadyExistsException (String message) {
        super(message);
    }
}
