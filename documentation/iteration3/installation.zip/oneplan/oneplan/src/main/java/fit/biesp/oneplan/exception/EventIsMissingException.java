package fit.biesp.oneplan.exception;

public class EventIsMissingException extends Exception {
    public EventIsMissingException (String message) {
        super(message);
    }
}
