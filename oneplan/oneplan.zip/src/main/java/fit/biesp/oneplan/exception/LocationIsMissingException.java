package fit.biesp.oneplan.exception;

public class LocationIsMissingException extends Exception {
    public LocationIsMissingException(String message) {
        super(message);
    }
}
